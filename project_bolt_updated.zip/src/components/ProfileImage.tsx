import * as React from "react";
import { ImageSource } from "@nativescript/core";

type ProfileImageProps = {
  source: string | ImageSource;
  size?: "sm" | "md" | "lg";
  className?: string;
};

export function ProfileImage({ source, size = "md", className = "" }: ProfileImageProps) {
  const sizeClasses = {
    sm: "w-16 h-16",
    md: "w-24 h-24",
    lg: "w-32 h-32"
  };

  return (
    <image
      className={`rounded-full ${sizeClasses[size]} ${className}`}
      src={source}
      stretch="aspectFill"
    />
  );
}