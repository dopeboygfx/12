import * as React from "react";
import { formatDistanceToNow } from "date-fns";
import { Message } from "../types/chat";

interface ChatBubbleProps {
  message: Message;
  isOwn: boolean;
}

export function ChatBubble({ message, isOwn }: ChatBubbleProps) {
  const bubbleStyle = isOwn
    ? "bg-purple-600 text-white ml-auto"
    : "bg-gray-200 text-gray-900";

  return (
    <gridLayout className={`rounded-lg p-3 max-w-3/4 mb-2 ${bubbleStyle}`}>
      <stackLayout>
        <label className="text-base" textWrap={true}>
          {message.content}
        </label>
        <label className="text-xs opacity-70">
          {formatDistanceToNow(message.timestamp, { addSuffix: true })}
        </label>
      </stackLayout>
    </gridLayout>
  );
}