import * as React from "react";
import { formatDistanceToNow } from "date-fns";
import { ChatRoom } from "../types/chat";
import { ProfileImage } from "./ProfileImage";

interface ChatRoomItemProps {
  room: ChatRoom;
  onPress: () => void;
}

export function ChatRoomItem({ room, onPress }: ChatRoomItemProps) {
  return (
    <gridLayout
      className="p-4 border-b border-gray-200"
      columns="auto, *, auto"
      rows="auto, auto"
      onTap={onPress}
    >
      <ProfileImage
        source="res://placeholder_avatar"
        size="sm"
        row={0}
        col={0}
        rowSpan={2}
        className="mr-3"
      />
      
      <label
        row={0}
        col={1}
        className="font-semibold text-gray-900"
        text={`User ${room.participants[1]}`}
      />
      
      <label
        row={1}
        col={1}
        className="text-sm text-gray-600"
        text={room.lastMessage?.content || "No messages yet"}
      />
      
      <stackLayout row={0} col={2} rowSpan={2} className="justify-center items-end">
        <label
          className="text-xs text-gray-500 mb-1"
          text={room.lastMessage 
            ? formatDistanceToNow(room.lastMessage.timestamp, { addSuffix: true })
            : ""}
        />
        {room.unreadCount > 0 && (
          <label
            className="bg-purple-600 text-white text-xs rounded-full px-2 py-1"
            text={room.unreadCount.toString()}
          />
        )}
      </stackLayout>
    </gridLayout>
  );
}