import * as React from "react";

type InterestTagProps = {
  text: string;
  onRemove?: () => void;
};

export function InterestTag({ text, onRemove }: InterestTagProps) {
  return (
    <gridLayout
      className="bg-purple-100 rounded-full px-4 py-2 m-1"
      columns={onRemove ? "auto, auto" : "auto"}
    >
      <label
        col={0}
        className="text-purple-800 text-sm"
        text={text}
      />
      {onRemove && (
        <button
          col={1}
          className="text-purple-600 ml-2 text-sm"
          text="×"
          onTap={onRemove}
        />
      )}
    </gridLayout>
  );
}