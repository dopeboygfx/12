import { create } from 'zustand';
import { Message, ChatRoom } from '../types/chat';

interface ChatState {
  messages: Record<string, Message[]>;
  chatRooms: ChatRoom[];
  activeChat: string | null;
  sendMessage: (roomId: string, content: string, senderId: string, receiverId: string) => void;
  markAsRead: (roomId: string) => void;
  setActiveChat: (roomId: string | null) => void;
}

export const useChatStore = create<ChatState>((set) => ({
  messages: {},
  chatRooms: [],
  activeChat: null,

  sendMessage: (roomId, content, senderId, receiverId) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      senderId,
      receiverId,
      content,
      timestamp: Date.now(),
      read: false,
    };

    set((state) => ({
      messages: {
        ...state.messages,
        [roomId]: [...(state.messages[roomId] || []), newMessage],
      },
      chatRooms: state.chatRooms.map((room) =>
        room.id === roomId
          ? { ...room, lastMessage: newMessage, unreadCount: room.unreadCount + 1 }
          : room
      ),
    }));
  },

  markAsRead: (roomId) => {
    set((state) => ({
      messages: {
        ...state.messages,
        [roomId]: state.messages[roomId]?.map((msg) => ({ ...msg, read: true })) || [],
      },
      chatRooms: state.chatRooms.map((room) =>
        room.id === roomId ? { ...room, unreadCount: 0 } : room
      ),
    }));
  },

  setActiveChat: (roomId) => set({ activeChat: roomId }),
}));