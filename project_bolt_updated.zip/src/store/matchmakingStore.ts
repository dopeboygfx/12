
import { create } from 'zustand';

const useMatchmakingStore = create((set) => ({
    matches: [], // Array of potential matches
    selectedMatch: null, // Currently viewed match

    addMatches: (newMatches) => set((state) => ({ matches: [...state.matches, ...newMatches] })),
    selectMatch: (match) => set({ selectedMatch: match }),
    clearMatches: () => set({ matches: [] }),
}));

export default useMatchmakingStore;
