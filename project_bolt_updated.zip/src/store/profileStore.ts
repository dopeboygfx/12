import { create } from 'zustand';

interface Profile {
  name?: string;
  photoUrl?: string;
  bio?: string;
  interests?: string[];
  location?: {
    latitude: number;
    longitude: number;
  };
}

interface ProfileState {
  profile: Profile;
  updateProfile: (updates: Partial<Profile>) => void;
}

export const useProfileStore = create<ProfileState>((set) => ({
  profile: {},
  updateProfile: (updates) => set((state) => ({
    profile: { ...state.profile, ...updates }
  })),
}));