
import { create } from 'zustand';

const useAuthStore = create((set) => ({
    user: null,
    isAuthenticated: false,
    token: null,

    login: (userData, token) => set({ user: userData, isAuthenticated: true, token }),
    logout: () => set({ user: null, isAuthenticated: false, token: null }),
}));

export default useAuthStore;
