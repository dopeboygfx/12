
// Matchmaking Algorithm

/**
 * Calculate compatibility scores for potential matches.
 * @param {Object} userProfile - The user's profile with personalityTraits, lifestylePreferences, and interests.
 * @param {Array} potentialMatches - Array of match profiles with the same structure as userProfile.
 * @returns {Array} Sorted list of matches with their compatibility scores.
 */
function calculateCompatibility(userProfile, potentialMatches) {
    const matchesWithScores = potentialMatches.map((match) => {
        let score = 0;

        // Personality Compatibility (40%)
        const personalityOverlap = calculateOverlap(userProfile.personalityTraits, match.personalityTraits);
        score += 0.4 * personalityOverlap;

        // Lifestyle Compatibility (40%)
        const lifestyleOverlap = calculateOverlap(userProfile.lifestylePreferences, match.lifestylePreferences);
        score += 0.4 * lifestyleOverlap;

        // Interest Compatibility (20%)
        const interestOverlap = calculateOverlap(userProfile.interests, match.interests);
        score += 0.2 * interestOverlap;

        return {
            match_id: match.id,
            score: parseFloat(score.toFixed(2)), // Round to 2 decimal places
        };
    });

    // Sort matches by score in descending order
    return matchesWithScores.sort((a, b) => b.score - a.score);
}

/**
 * Calculate the percentage of overlap between two arrays.
 * @param {Array} list1 - First list of attributes.
 * @param {Array} list2 - Second list of attributes.
 * @returns {number} Overlap percentage (0 to 100).
 */
function calculateOverlap(list1, list2) {
    const set1 = new Set(list1);
    const set2 = new Set(list2);
    const overlap = [...set1].filter((item) => set2.has(item));
    return (overlap.length / new Set([...list1, ...list2]).size) * 100;
}

module.exports = { calculateCompatibility, calculateOverlap };
