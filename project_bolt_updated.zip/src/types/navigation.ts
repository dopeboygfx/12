export type RootStackParamList = {
  Welcome: undefined;
  Login: undefined;
  SignUp: undefined;
  Profile: undefined;
  Matches: undefined;
  ChatList: undefined;
  Chat: { matchId: string };
};