import * as React from "react";
import { BaseNavigationContainer } from "@react-navigation/core";
import { stackNavigatorFactory } from "react-nativescript-navigation";
import { WelcomeScreen } from "../screens/WelcomeScreen";
import { LoginScreen } from "../screens/LoginScreen";
import { SignUpScreen } from "../screens/SignUpScreen";
import { MatchesScreen } from "../screens/MatchesScreen";
import { ProfileScreen } from "../screens/ProfileScreen";
import { ChatListScreen } from "../screens/ChatListScreen";
import { ChatScreen } from "../screens/ChatScreen";
import { RootStackParamList } from "../types/navigation";
import { useAuthStore } from "../store/authStore";

const Stack = stackNavigatorFactory();

export function AppNavigator() {
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);

  return (
    <BaseNavigationContainer>
      <Stack.Navigator
        initialRouteName={isAuthenticated ? "Matches" : "Welcome"}
        screenOptions={{
          headerShown: true,
          headerStyle: {
            backgroundColor: "#9333ea",
          },
          headerTintColor: "#ffffff",
        }}
      >
        <Stack.Screen 
          name="Welcome" 
          component={WelcomeScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen 
          name="Login" 
          component={LoginScreen}
          options={{ headerTitle: "Login" }}
        />
        <Stack.Screen 
          name="SignUp" 
          component={SignUpScreen}
          options={{ headerTitle: "Sign Up" }}
        />
        <Stack.Screen 
          name="Matches" 
          component={MatchesScreen}
          options={{ headerTitle: "Your Matches" }}
        />
        <Stack.Screen 
          name="Profile" 
          component={ProfileScreen}
          options={{ headerTitle: "Edit Profile" }}
        />
        <Stack.Screen 
          name="ChatList" 
          component={ChatListScreen}
          options={{ headerTitle: "Messages" }}
        />
        <Stack.Screen 
          name="Chat" 
          component={ChatScreen}
          options={({ route }) => ({ 
            headerTitle: `Chat with User ${route.params.matchId}`,
          })}
        />
      </Stack.Navigator>
    </BaseNavigationContainer>
  );
}