
import React from 'react';
import { View, Text, Button, Image } from 'react-nativescript';

const DetailedMatchView = ({ route, navigation }) => {
    const { matchId } = route.params;

    // Mock match details (this would typically come from an API)
    const matchDetails = {
        id: matchId,
        name: 'Alex',
        compatibility: '85%',
        photo: 'https://via.placeholder.com/200',
        interests: ['Hiking', 'Photography', 'Traveling'],
        bio: 'Outdoor enthusiast who loves exploring new places.',
    };

    return (
        <View style={{ padding: 20 }}>
            <Image source={{ uri: matchDetails.photo }} style={{ width: 200, height: 200, borderRadius: 100 }} />
            <Text style={{ fontSize: 20, fontWeight: 'bold' }}>{matchDetails.name}</Text>
            <Text>Compatibility: {matchDetails.compatibility}</Text>
            <Text style={{ marginVertical: 10 }}>{matchDetails.bio}</Text>
            <Text>Interests:</Text>
            {matchDetails.interests.map((interest, index) => (
                <Text key={index}>- {interest}</Text>
            ))}
            <Button title="Go Back" onPress={() => navigation.goBack()} />
        </View>
    );
};

export default DetailedMatchView;
