import * as React from "react";
import { RouteProp } from "@react-navigation/core";
import { FrameNavigationProp } from "react-nativescript-navigation";
import { RootStackParamList } from "../types/navigation";
import { useAuthStore } from "../store/authStore";

type LoginScreenProps = {
  route: RouteProp<RootStackParamList, "Login">;
  navigation: FrameNavigationProp<RootStackParamList, "Login">;
};

export function LoginScreen({ navigation }: LoginScreenProps) {
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const login = useAuthStore((state) => state.login);

  const handleLogin = () => {
    // TODO: Implement actual authentication
    login({ email });
    navigation.navigate("Matches");
  };

  return (
    <flexboxLayout className="h-full flex-col justify-start items-center bg-purple-50 p-8">
      <label className="text-2xl font-bold mb-8 text-purple-800">Welcome Back</label>
      
      <textField
        className="w-full p-4 mb-4 rounded-lg border-2 border-purple-200"
        hint="Email"
        keyboardType="email"
        text={email}
        onTextChange={(args) => setEmail(args.value)}
      />
      
      <textField
        className="w-full p-4 mb-6 rounded-lg border-2 border-purple-200"
        hint="Password"
        secure={true}
        text={password}
        onTextChange={(args) => setPassword(args.value)}
      />
      
      <button
        className="bg-purple-600 text-white p-4 rounded-lg w-full text-center mb-4"
        onTap={handleLogin}
      >
        Login
      </button>
      
      <button
        className="text-purple-600 p-2"
        onTap={() => navigation.navigate("SignUp")}
      >
        Don't have an account? Sign Up
      </button>
    </flexboxLayout>
  );
}