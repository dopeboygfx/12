import * as React from "react";
import { RouteProp } from "@react-navigation/core";
import { FrameNavigationProp } from "react-nativescript-navigation";
import { RootStackParamList } from "../types/navigation";
import { ProfileImage } from "../components/ProfileImage";
import { InterestTag } from "../components/InterestTag";
import { useProfileStore } from "../store/profileStore";

type ProfileScreenProps = {
  route: RouteProp<RootStackParamList, "Profile">;
  navigation: FrameNavigationProp<RootStackParamList, "Profile">;
};

export function ProfileScreen({ navigation }: ProfileScreenProps) {
  const { profile, updateProfile } = useProfileStore();
  const [newInterest, setNewInterest] = React.useState("");

  const handleAddInterest = () => {
    if (newInterest.trim()) {
      updateProfile({
        interests: [...(profile.interests || []), newInterest.trim()]
      });
      setNewInterest("");
    }
  };

  const handleRemoveInterest = (interest: string) => {
    updateProfile({
      interests: profile.interests?.filter(i => i !== interest)
    });
  };

  return (
    <scrollView className="bg-purple-50">
      <flexboxLayout className="flex-col p-4">
        <stackLayout className="items-center mb-6">
          <ProfileImage
            source={profile.photoUrl || "res://placeholder_avatar"}
            size="lg"
            className="mb-4"
          />
          <button
            className="bg-purple-600 text-white px-4 py-2 rounded-full"
            text="Change Photo"
          />
        </stackLayout>

        <label className="text-sm text-purple-800 mb-2">Name</label>
        <textField
          className="bg-white p-4 rounded-lg mb-4"
          text={profile.name || ""}
          hint="Your name"
          onTextChange={(args) => updateProfile({ name: args.value })}
        />

        <label className="text-sm text-purple-800 mb-2">Bio</label>
        <textView
          className="bg-white p-4 rounded-lg mb-4 h-32"
          text={profile.bio || ""}
          hint="Tell us about yourself..."
          onTextChange={(args) => updateProfile({ bio: args.value })}
        />

        <label className="text-sm text-purple-800 mb-2">Interests</label>
        <gridLayout columns="*, auto" className="mb-4">
          <textField
            col={0}
            className="bg-white p-4 rounded-lg"
            text={newInterest}
            hint="Add an interest"
            onTextChange={(args) => setNewInterest(args.value)}
          />
          <button
            col={1}
            className="bg-purple-600 text-white ml-2 px-6 rounded-lg"
            text="Add"
            onTap={handleAddInterest}
          />
        </gridLayout>

        <wrapLayout className="mb-4">
          {profile.interests?.map((interest) => (
            <InterestTag
              key={interest}
              text={interest}
              onRemove={() => handleRemoveInterest(interest)}
            />
          ))}
        </wrapLayout>
      </flexboxLayout>
    </scrollView>
  );
}