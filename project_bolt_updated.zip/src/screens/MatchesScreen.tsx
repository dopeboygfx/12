import * as React from "react";
import { RouteProp } from "@react-navigation/core";
import { FrameNavigationProp } from "react-nativescript-navigation";
import { RootStackParamList } from "../types/navigation";

type MatchesScreenProps = {
  route: RouteProp<RootStackParamList, "Matches">;
  navigation: FrameNavigationProp<RootStackParamList, "Matches">;
};

export function MatchesScreen({ navigation }: MatchesScreenProps) {
  return (
    <flexboxLayout className="h-full flex-col justify-start items-center bg-purple-50 p-4">
      <label className="text-2xl font-bold mb-6 text-purple-800">Your Matches</label>
      
      <scrollView className="w-full">
        <stackLayout className="w-full">
          {/* Placeholder matches - will be replaced with real data */}
          {[1, 2, 3].map((i) => (
            <gridLayout 
              key={i}
              className="w-full bg-white rounded-lg p-4 mb-4 shadow-sm"
              rows="auto, auto" 
              columns="80, *"
            >
              <image
                row={0}
                col={0}
                rowSpan={2}
                className="w-20 h-20 rounded-full"
                src="res://placeholder_avatar"
              />
              <label 
                row={0} 
                col={1}
                className="text-lg font-semibold text-purple-900 ml-4"
              >
                Match {i}
              </label>
              <label 
                row={1} 
                col={1}
                className="text-sm text-purple-600 ml-4"
              >
                85% Match
              </label>
            </gridLayout>
          ))}
        </stackLayout>
      </scrollView>
    </flexboxLayout>
  );
}