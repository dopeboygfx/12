
import React, { useState } from 'react';
import { View, Text, Button, TextInput } from 'react-nativescript';

const OnboardingScreen = ({ navigation }) => {
    const [step, setStep] = useState(1);
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');

    const handleNext = () => {
        if (step < 3) {
            setStep(step + 1);
        } else {
            navigation.navigate('MatchFeed');
        }
    };

    return (
        <View style={{ padding: 20 }}>
            {step === 1 && (
                <View>
                    <Text>Welcome! Let's start with your name.</Text>
                    <TextInput value={name} onChangeText={setName} placeholder="Enter your name" />
                </View>
            )}
            {step === 2 && (
                <View>
                    <Text>What's your email?</Text>
                    <TextInput value={email} onChangeText={setEmail} placeholder="Enter your email" />
                </View>
            )}
            {step === 3 && (
                <View>
                    <Text>Thank you! Ready to start finding matches?</Text>
                </View>
            )}
            <Button title={step < 3 ? 'Next' : 'Finish'} onPress={handleNext} />
        </View>
    );
};

export default OnboardingScreen;
