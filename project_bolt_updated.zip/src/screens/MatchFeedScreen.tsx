
import React, { useState } from 'react';
import { View, Text, Button, FlatList, Image } from 'react-nativescript';

const matches = [
    { id: '1', name: 'Alex', compatibility: '85%', photo: 'https://via.placeholder.com/100' },
    { id: '2', name: 'Jamie', compatibility: '78%', photo: 'https://via.placeholder.com/100' },
    { id: '3', name: 'Taylor', compatibility: '90%', photo: 'https://via.placeholder.com/100' },
];

const MatchFeedScreen = ({ navigation }) => {
    const [liked, setLiked] = useState([]);

    const handleLike = (id) => {
        setLiked((prev) => [...prev, id]);
    };

    const renderMatch = ({ item }) => (
        <View style={{ margin: 10, padding: 10, borderWidth: 1, borderRadius: 5 }}>
            <Image source={{ uri: item.photo }} style={{ width: 100, height: 100 }} />
            <Text>Name: {item.name}</Text>
            <Text>Compatibility: {item.compatibility}</Text>
            <Button title="Like" onPress={() => handleLike(item.id)} />
            <Button title="View Details" onPress={() => navigation.navigate('MatchDetails', { matchId: item.id })} />
        </View>
    );

    return (
        <View style={{ padding: 20 }}>
            <Text>Match Feed</Text>
            <FlatList data={matches} renderItem={renderMatch} keyExtractor={(item) => item.id} />
        </View>
    );
};

export default MatchFeedScreen;
