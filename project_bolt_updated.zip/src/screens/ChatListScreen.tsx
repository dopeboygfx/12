import * as React from "react";
import { RouteProp } from "@react-navigation/core";
import { FrameNavigationProp } from "react-nativescript-navigation";
import { RootStackParamList } from "../types/navigation";
import { ChatRoomItem } from "../components/ChatRoomItem";
import { useChatStore } from "../store/chatStore";

type ChatListScreenProps = {
  route: RouteProp<RootStackParamList, "ChatList">;
  navigation: FrameNavigationProp<RootStackParamList, "ChatList">;
};

export function ChatListScreen({ navigation }: ChatListScreenProps) {
  const chatRooms = useChatStore((state) => state.chatRooms);

  return (
    <flexboxLayout className="h-full bg-white">
      <scrollView className="w-full">
        <stackLayout>
          {chatRooms.map((room) => (
            <ChatRoomItem
              key={room.id}
              room={room}
              onPress={() => navigation.navigate("Chat", { matchId: room.id })}
            />
          ))}
          {chatRooms.length === 0 && (
            <flexboxLayout className="h-full justify-center items-center p-8">
              <label className="text-gray-500 text-center">
                No conversations yet. Start matching to chat!
              </label>
            </flexboxLayout>
          )}
        </stackLayout>
      </scrollView>
    </flexboxLayout>
  );
}