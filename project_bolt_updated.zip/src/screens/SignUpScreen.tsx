import * as React from "react";
import { RouteProp } from "@react-navigation/core";
import { FrameNavigationProp } from "react-nativescript-navigation";
import { RootStackParamList } from "../types/navigation";
import { useAuthStore } from "../store/authStore";

type SignUpScreenProps = {
  route: RouteProp<RootStackParamList, "SignUp">;
  navigation: FrameNavigationProp<RootStackParamList, "SignUp">;
};

export function SignUpScreen({ navigation }: SignUpScreenProps) {
  const [name, setName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const login = useAuthStore((state) => state.login);

  const handleSignUp = () => {
    // TODO: Implement actual registration
    login({ email, name });
    navigation.navigate("Profile");
  };

  return (
    <flexboxLayout className="h-full flex-col justify-start items-center bg-purple-50 p-8">
      <label className="text-2xl font-bold mb-8 text-purple-800">Create Account</label>
      
      <textField
        className="w-full p-4 mb-4 rounded-lg border-2 border-purple-200"
        hint="Full Name"
        text={name}
        onTextChange={(args) => setName(args.value)}
      />
      
      <textField
        className="w-full p-4 mb-4 rounded-lg border-2 border-purple-200"
        hint="Email"
        keyboardType="email"
        text={email}
        onTextChange={(args) => setEmail(args.value)}
      />
      
      <textField
        className="w-full p-4 mb-6 rounded-lg border-2 border-purple-200"
        hint="Password"
        secure={true}
        text={password}
        onTextChange={(args) => setPassword(args.value)}
      />
      
      <button
        className="bg-purple-600 text-white p-4 rounded-lg w-full text-center mb-4"
        onTap={handleSignUp}
      >
        Sign Up
      </button>
      
      <button
        className="text-purple-600 p-2"
        onTap={() => navigation.navigate("Login")}
      >
        Already have an account? Login
      </button>
    </flexboxLayout>
  );
}