import * as React from "react";
import { RouteProp } from "@react-navigation/core";
import { FrameNavigationProp } from "react-nativescript-navigation";
import { RootStackParamList } from "../types/navigation";
import { ChatBubble } from "../components/ChatBubble";
import { useChatStore } from "../store/chatStore";
import { useAuthStore } from "../store/authStore";

type ChatScreenProps = {
  route: RouteProp<RootStackParamList, "Chat">;
  navigation: FrameNavigationProp<RootStackParamList, "Chat">;
};

export function ChatScreen({ route, navigation }: ChatScreenProps) {
  const { matchId } = route.params;
  const [message, setMessage] = React.useState("");
  const messages = useChatStore((state) => state.messages[matchId] || []);
  const sendMessage = useChatStore((state) => state.sendMessage);
  const markAsRead = useChatStore((state) => state.markAsRead);
  const currentUser = useAuthStore((state) => state.user);

  React.useEffect(() => {
    markAsRead(matchId);
  }, [matchId]);

  const handleSend = () => {
    if (message.trim()) {
      sendMessage(matchId, message.trim(), currentUser.id, matchId);
      setMessage("");
    }
  };

  return (
    <gridLayout rows="*, auto" className="bg-gray-100">
      <scrollView row={0} className="p-4">
        <stackLayout>
          {messages.map((msg) => (
            <ChatBubble
              key={msg.id}
              message={msg}
              isOwn={msg.senderId === currentUser.id}
            />
          ))}
        </stackLayout>
      </scrollView>

      <gridLayout
        row={1}
        columns="*, auto"
        className="bg-white p-4 border-t border-gray-200"
      >
        <textField
          col={0}
          className="bg-gray-100 rounded-full px-4 py-2"
          hint="Type a message..."
          text={message}
          onTextChange={(args) => setMessage(args.value)}
        />
        <button
          col={1}
          className="ml-2 bg-purple-600 text-white rounded-full w-12 h-12"
          text="→"
          isEnabled={message.trim().length > 0}
          onTap={handleSend}
        />
      </gridLayout>
    </gridLayout>
  );
}