import * as React from "react";
import { RouteProp } from "@react-navigation/core";
import { FrameNavigationProp } from "react-nativescript-navigation";
import { RootStackParamList } from "../types/navigation";

type WelcomeScreenProps = {
  route: RouteProp<RootStackParamList, "Welcome">;
  navigation: FrameNavigationProp<RootStackParamList, "Welcome">;
};

export function WelcomeScreen({ navigation }: WelcomeScreenProps) {
  return (
    <flexboxLayout className="h-full flex-col justify-center items-center bg-purple-100">
      <label className="text-3xl font-bold mb-8 text-purple-800">
        Find Your Perfect Match
      </label>
      <button
        className="bg-purple-600 text-white p-4 rounded-lg mb-4 w-64 text-center"
        onTap={() => navigation.navigate("Login")}
      >
        Login
      </button>
      <button
        className="bg-purple-800 text-white p-4 rounded-lg w-64 text-center"
        onTap={() => navigation.navigate("SignUp")}
      >
        Sign Up
      </button>
    </flexboxLayout>
  );
}