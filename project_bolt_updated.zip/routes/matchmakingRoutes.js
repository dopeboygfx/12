
const express = require('express');
const { calculateCompatibility } = require('../utils/matchmaking');

const router = express.Router();

/**
 * POST /calculate-matches
 * Calculate compatibility scores for potential matches.
 * Request Body:
 *  - userProfile: { personalityTraits, lifestylePreferences, interests }
 *  - potentialMatches: Array of match profiles
 * Response:
 *  - Array of matches with compatibility scores
 */
router.post('/calculate-matches', (req, res) => {
    try {
        const { userProfile, potentialMatches } = req.body;

        if (!userProfile || !potentialMatches) {
            return res.status(400).json({ error: 'Missing userProfile or potentialMatches' });
        }

        const matchesWithScores = calculateCompatibility(userProfile, potentialMatches);
        return res.json(matchesWithScores);
    } catch (error) {
        console.error('Error calculating matches:', error);
        return res.status(500).json({ error: 'Internal server error' });
    }
});

module.exports = router;
